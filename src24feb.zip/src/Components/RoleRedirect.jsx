import { Navigate } from "react-router-dom";
import { useAuth } from "../Context/AuthContext";
 
function RoleRedirect() {
  const { user, role, loading } = useAuth();

  if (loading) {
    return <div>Loading authentication...</div>;
  }

  if (!user) {
    return <Navigate to="/login" replace />;
  }

  // Role still loading
  if (role === undefined) {
    return <div>Loading role...</div>;
  }

  if (role === "client") {
    return <Navigate to="/client/dashboard" replace />;
  }

  if (role === "freelancer") {
    return <Navigate to="/freelancer/dashboard" replace />;
  }

  return <Navigate to="/login" replace />;
}

export default RoleRedirect;