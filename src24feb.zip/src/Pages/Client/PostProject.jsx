import { useState } from "react"
import { useAuth } from "../../Context/AuthContext"
import { createProject } from "../../Services/projectService"
import { useNavigate } from "react-router-dom"

function PostProject() {

 const {user} = useAuth()
 const navigate = useNavigate()

 const [title, setTitle] = useState("")
 const [description, setDescription] = useState("")
 const [budget, setBudget] = useState("")
 const[skills, setSkills] = useState("")
 const[deadline,setDeadline] =useState("")


 const handleSubmit = async (e) => {
    e.preventDefault()
    try{
        await createProject({
            title,
            description,
            budget,
            skills,
            deadline,
            clientId: user.uid
        })
        navigate("/client/dashboard")
    }catch(error){
        console.error("Error creating project:", error)
    }
}



    return (
         <div className="max-w-xl mx-auto p-6">
      <h2 className="text-2xl font-bold mb-4">Post a Project</h2>

      <form onSubmit={handleSubmit} className="space-y-4">
        <input
          className="w-full border p-2"
          placeholder="Project Title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          required
        />

        <textarea
          className="w-full border p-2"
          placeholder="Project Description"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          required
        />

        <input
          className="w-full border p-2"
          placeholder="Budget"
          value={budget}
          onChange={(e) => setBudget(e.target.value)}
          required
        />

        <input
          className="w-full border p-2"
          placeholder="Required Skills (comma separated)"
          value={skills}
          onChange={(e) => setSkills(e.target.value)}
          required
        />
         <input
          type="date"
          className="w-full border p-2"
          placeholder="Deadline"
          value={deadline}
          onChange={(e) => setDeadline(e.target.value)}
          required
        />

        <button className="bg-indigo-600 text-white px-4 py-2 rounded">
          Post Project
        </button>
      </form>
    </div>
  );
    
}

export default PostProject
