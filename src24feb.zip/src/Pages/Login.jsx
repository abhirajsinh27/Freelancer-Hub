import { useState } from "react";
import { signInWithEmailAndPassword } from "firebase/auth";
import { auth } from "../firebase/firebase";
import { useNavigate } from "react-router-dom";

function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    setError(null);

    try {
      await signInWithEmailAndPassword(auth, email, password);
      console.log("Login successful");
      navigate("/");
      // AuthContext will automatically:
      // - set user
      // - fetch role from Firestore
    } catch (err) {
      console.error(err);
      setError(err.message);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-linear-to-br from-[#4b6cb7] to-[#182848]">
      <div className="w-full max-w-md rounded-xl border border-white/20 bg-white/10 backdrop-blur-lg shadow-2xl p-8">
        <form onSubmit={handleLogin} className="space-y-4">
          <h2 className="text-2xl font-semibold text-white text-center mb-6">
            Login
          </h2>

          {error && (
            <p className="text-red-500 text-sm">{error}</p>
          )}

          <input
            type="email"
            placeholder="Email"
            className="w-full rounded-md bg-white/10 border border-white/20 px-4 py-2 text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-indigo-400"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />

          <input
            type="password"
            placeholder="Password"
            className="w-full rounded-md bg-white/10 border border-white/20 px-4 py-2 text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-indigo-400"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />

          <button
            type="submit"

            className="w-full bg-indigo-500 hover:bg-indigo-600 transition text-white font-medium py-2 rounded-md shadow-lg"
          >
            Login
          </button>
          <button
            type="button"
            onClick={() => navigate("/signup")}
            className="w-full bg-gray-500 hover:bg-gray-600 transition text-white font-medium py-2 rounded-md shadow-lg"
          >
            Don't have an account? Sign Up
            </button>
        </form>
      </div>
    </div>
  );
}

export default Login;
