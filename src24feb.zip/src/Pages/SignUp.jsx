import React, { useState } from "react";
import { createUserWithEmailAndPassword } from "firebase/auth";
import { auth } from "../firebase/firebase";
import { doc, setDoc } from "firebase/firestore";
import { db } from "../firebase/firebase";
import { useNavigate } from "react-router-dom";

function SignUp() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState("freelancer");
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  const handleSignup = async (e) => {
  e.preventDefault();
  setError(null);

  try {
    const userCredential = await createUserWithEmailAndPassword(
      auth,
      email,
      password
    );

    console.log("Auth success");
    navigate("/login");

    const user = userCredential.user;

    await setDoc(doc(db, "users", user.uid), {
      email: user.email,
      role: role,
      createdAt: new Date(),
    });

    console.log("🔥 Firestore write success");

  } catch (err) {
    console.error("Signup error:", err);
    setError(err.message);
  }
};


  return (
    <div className="min-h-screen flex items-center justify-center bg-linear-to-br from-[#4b6cb7] to-[#182848]">
      <div className="w-full max-w-md rounded-xl border border-white/20 bg-white/10 backdrop-blur-lg shadow-2xl p-8">
        <form onSubmit={handleSignup} className="space-y-4">
          <h2 className="text-2xl font-semibold text-white text-center mb-6">
            Sign Up
          </h2>

          {error && <p className="text-red-500 text-sm mb-2">{error}</p>}

          <input
            type="email"
            placeholder="Email"
            className="w-full rounded-md bg-white/10 border border-white/20 px-4 py-2 text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-indigo-400"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />

          <input
            type="password"
            placeholder="Password"
            className="w-full rounded-md bg-white/10 border border-white/20 px-4 py-2 text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-indigo-400"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />

          <select
            className="w-full mb-4 rounded-md bg-white/10 border border-white/20 px-4 py-2 text-white
             focus:outline-none focus:ring-2 focus:ring-indigo-400"
            value={role}
            onChange={(e) => setRole(e.target.value)}
          >
            <option value="freelancer" className="text-black">
              Freelancer
            </option>
            <option value="client" className="text-black">
              Client
            </option>
          </select>

          <button
            type="submit"
            className="w-full bg-indigo-500 hover:bg-indigo-600 transition text-white font-medium py-2 rounded-md shadow-lg"
          >
            Create Account
          </button>
        </form>
      </div>
    </div>
  );
}
export default SignUp;
