import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.jsx'
import { AuthProvider } from './Context/AuthContext'
import { BrowserRouter } from 'react-router-dom'

createRoot(document.getElementById('root')).render(
   <BrowserRouter>
   <AuthProvider>
     <App/>
  </AuthProvider>
    </BrowserRouter>
)
